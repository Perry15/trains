import 'package:firebase_auth/firebase_auth.dart';

class AuthService{
  //_ before meanbs private
  final FirebaseAuth _auth = FirebaseAuth.instance;

  //sign in anon
  Future signInAnon() async{
    try{
      AuthResult result = await _auth.signInAnonymously();
      FirebaseUser user = result.user;
      return user;//success
    } catch(e){
      print(e.toString());
      return null;//failure
    }
  }
  //sign in with email & password

  //register with email & password

  //sign out

}