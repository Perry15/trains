import 'package:flutter/material.dart';
import 'package:myapp/services/auth.dart';
class SignIn extends StatefulWidget {
  @override
  _SignInState createState() => _SignInState();
}

class _SignInState extends State<SignIn> {

  final AuthService _authService = AuthService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.brown[100],
      appBar: AppBar(
        backgroundColor: Colors.brown[400],
        elevation:0.0, //remove drop shadow?
        title: Text('Accedi'),
      ),
      body: Container(
        padding: EdgeInsets.symmetric(vertical:20.0, horizontal: 50.0), //4 side symmetric padding
        child: RaisedButton(
          child: Text('Accesso anonimo'),
          onPressed: () async { //async perchè accesso era async
            dynamic result = await _authService.signInAnon();//return user in succes or null in failure
            if(result == null){
              print('errore di accesso');
            }
            else{
              print('accesso avvenuto');
              print(result);
            }
          },
        )
      )
    );
  }
}
